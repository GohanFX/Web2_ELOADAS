import Auth from './Auth'
import ContactController from './ContactController'
import DashboardController from './DashboardController'
import DriverController from './DriverController'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
ContactController: Object.assign(ContactController, ContactController),
DashboardController: Object.assign(DashboardController, DashboardController),
DriverController: Object.assign(DriverController, DriverController),
}

export default Controllers