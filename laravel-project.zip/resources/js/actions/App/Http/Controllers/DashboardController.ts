import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
export const database = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: database.url(options),
    method: 'get',
})

database.definition = {
    methods: ["get","head"],
    url: '/database',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
database.url = (options?: RouteQueryOptions) => {
    return database.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
database.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: database.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
database.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: database.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
    const databaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: database.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
        databaseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: database.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::database
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/database'
 */
        databaseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: database.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    database.form = databaseForm
/**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
export const chart = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chart.url(options),
    method: 'get',
})

chart.definition = {
    methods: ["get","head"],
    url: '/chart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
chart.url = (options?: RouteQueryOptions) => {
    return chart.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
chart.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chart.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
chart.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: chart.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
    const chartForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: chart.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
        chartForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chart.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::chart
 * @see app/Http/Controllers/DashboardController.php:32
 * @route '/chart'
 */
        chartForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chart.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    chart.form = chartForm
/**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
export const admin = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: admin.url(options),
    method: 'get',
})

admin.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
admin.url = (options?: RouteQueryOptions) => {
    return admin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
admin.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: admin.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
admin.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: admin.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
    const adminForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: admin.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
        adminForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: admin.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::admin
 * @see app/Http/Controllers/DashboardController.php:58
 * @route '/admin'
 */
        adminForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: admin.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    admin.form = adminForm
const DashboardController = { database, chart, admin }

export default DashboardController