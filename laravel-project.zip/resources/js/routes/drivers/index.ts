import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/drivers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriverController::index
 * @see app/Http/Controllers/DriverController.php:13
 * @route '/drivers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/drivers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriverController::create
 * @see app/Http/Controllers/DriverController.php:22
 * @route '/drivers/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\DriverController::store
 * @see app/Http/Controllers/DriverController.php:27
 * @route '/drivers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/drivers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DriverController::store
 * @see app/Http/Controllers/DriverController.php:27
 * @route '/drivers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriverController::store
 * @see app/Http/Controllers/DriverController.php:27
 * @route '/drivers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DriverController::store
 * @see app/Http/Controllers/DriverController.php:27
 * @route '/drivers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriverController::store
 * @see app/Http/Controllers/DriverController.php:27
 * @route '/drivers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
export const edit = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/drivers/{driver}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
edit.url = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driver: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driver: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driver: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driver: typeof args.driver === 'object'
                ? args.driver.id
                : args.driver,
                }

    return edit.definition.url
            .replace('{driver}', parsedArgs.driver.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
edit.get = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
edit.head = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
    const editForm = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
        editForm.get = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DriverController::edit
 * @see app/Http/Controllers/DriverController.php:41
 * @route '/drivers/{driver}/edit'
 */
        editForm.head = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
export const update = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/drivers/{driver}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
update.url = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driver: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driver: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driver: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driver: typeof args.driver === 'object'
                ? args.driver.id
                : args.driver,
                }

    return update.definition.url
            .replace('{driver}', parsedArgs.driver.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
update.put = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
update.patch = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
    const updateForm = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
        updateForm.put = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\DriverController::update
 * @see app/Http/Controllers/DriverController.php:48
 * @route '/drivers/{driver}'
 */
        updateForm.patch = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DriverController::destroy
 * @see app/Http/Controllers/DriverController.php:62
 * @route '/drivers/{driver}'
 */
export const destroy = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/drivers/{driver}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DriverController::destroy
 * @see app/Http/Controllers/DriverController.php:62
 * @route '/drivers/{driver}'
 */
destroy.url = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { driver: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { driver: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    driver: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        driver: typeof args.driver === 'object'
                ? args.driver.id
                : args.driver,
                }

    return destroy.definition.url
            .replace('{driver}', parsedArgs.driver.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DriverController::destroy
 * @see app/Http/Controllers/DriverController.php:62
 * @route '/drivers/{driver}'
 */
destroy.delete = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DriverController::destroy
 * @see app/Http/Controllers/DriverController.php:62
 * @route '/drivers/{driver}'
 */
    const destroyForm = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DriverController::destroy
 * @see app/Http/Controllers/DriverController.php:62
 * @route '/drivers/{driver}'
 */
        destroyForm.delete = (args: { driver: string | number | { id: string | number } } | [driver: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const drivers = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default drivers